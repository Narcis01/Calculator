﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CalculatorProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn7_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "7";
        }

        private void btn8_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "8";
        }

        private void btn9_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "9";
        }

        private void btnX_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "*";
        }

        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "4";
        }

        private void btn5_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "5";
        }

        private void btn6_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "6";
        }

        private void btnMinus_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "-";
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "1";
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "2";
        }

        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "3";
        }

        private void btnPlus_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "+";
        }

        private void btnDot_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + ".";
        }

        private void btn0_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "0";
        }

        private void btnEq_Click(object sender, RoutedEventArgs e)
        {
            String text = result.Text;
            String n1 = "";
            String sign = "";
            String n2 = "";
            int ok = 0;

            for(int i=0;i<text.Length;i++)
            {
                if(text[i]!='+' && text[i]!='-' && text[i]!='/' && text[i]!='*' && ok==0)
                {
                    n1 += text[i];
                }
                else if(text[i] != '+' && text[i] != '-' && text[i] != '/' && text[i] != '*' && ok == 1)
                {
                    n2 += text[i];
                }
                    else
                {
                    sign += text[i];
                    ok = 1;
                }

            }

            double number1 = Convert.ToDouble(n1);
            double number2 = Convert.ToDouble(n2);

            if(sign == "+")
            {
                double sum = number1 + number2;

                result.Text = Convert.ToString(sum);
            }
            else if(sign == "-")
            {
                double min = number1 - number2;

                result.Text = Convert.ToString(min);
            }
                else if(sign == "*")
            {
                double prod = number1 * number2;

                result.Text = Convert.ToString(prod);
            }
                    else
                    {
                double div = number1 / number2;

                result.Text = Convert.ToString(div);
                    }
                
        }

        private void btnDiv_Click(object sender, RoutedEventArgs e)
        {
            result.Text = result.Text + "/";
        }

        private void reset_Click(object sender, RoutedEventArgs e)
        {
            result.Text = "";
        }
    }
}
